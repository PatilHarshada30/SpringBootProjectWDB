package com.jbk.exceptions;

public class ResourceNotExistsExceptions extends RuntimeException {
	public ResourceNotExistsExceptions(String msg) {
		super(msg);
	}
}
