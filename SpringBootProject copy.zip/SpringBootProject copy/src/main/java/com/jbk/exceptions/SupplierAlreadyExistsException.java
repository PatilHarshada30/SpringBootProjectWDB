package com.jbk.exceptions;

public class SupplierAlreadyExistsException extends RuntimeException {

	public SupplierAlreadyExistsException(String msg) {
		super(msg);
	}
}
